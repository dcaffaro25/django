"""
Experimental journal entry suggestion utilities.

The categorisation model predicts a single account for each transaction,
which is sufficient for allocating the expense or revenue side of a
transaction. In a double‑entry accounting system, however, every
transaction generates at least two journal entries: a debit and a credit.

This module contains stubs for training and using a multi‑label classifier
that attempts to predict the full set of journal entry lines for a given
transaction. The implementation provided here is intentionally
straightforward and assumes that each journal entry line can be modelled
independently. It uses a scikit‑learn `OneVsRestClassifier` with a
`LogisticRegression` base estimator to predict labels of the form
``"debit:<account_id>"`` and ``"credit:<account_id>"``. The code
illustrates how you might build such a model, but it may require further
tuning to perform well in production.

Note that multi‑label prediction of journal entries is an inherently
challenging problem because the number of possible label combinations grows
quickly with the number of accounts. In practice, you may choose to
decompose the problem: predict the primary account with the
categorisation model and handle the opposite side via deterministic rules
or a separate classifier. You should evaluate both approaches against
your historical data and business rules.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Tuple, Iterable

import pandas as pd
try:
    from django.conf import settings  # type: ignore
except Exception:
    # Provide a fallback settings object with a BASE_DIR attribute when
    # Django is unavailable (e.g. during tests outside the app).
    import os
    import types

    settings = types.SimpleNamespace(BASE_DIR=os.getcwd())  # type: ignore
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler

import joblib

try:
    from accounting.models import Account, JournalEntry, Transaction
except Exception:
    Account = None  # type: ignore
    JournalEntry = None  # type: ignore
    Transaction = None  # type: ignore


def _assemble_journal_training_data(
    company_id: int,
    max_records: int = 10000,
    include_pending: bool = False,
) -> Tuple[pd.DataFrame, List[List[str]]]:
    """Collect training examples for journal entry suggestion.

    For each transaction, we gather its description and amount as features and
    the set of journal entry lines as labels. Each label is encoded as
    ``"debit:<account_id>"`` or ``"credit:<account_id>"``. We skip
    transactions with more than two lines (to keep the task tractable).

    Returns
    -------
    df_features, labels
        A tuple consisting of the feature DataFrame and a list of label lists
        for each row.
    """
    if Account is None or JournalEntry is None or Transaction is None:
        raise RuntimeError("Journal training requires the accounting models to be available.")

    # Fetch transactions with their journal entries
    tx_qs = (
        Transaction.objects.filter(company_id=company_id)
        .select_related()
        .prefetch_related("journal_entries")
        .order_by("-date")
    )
    if not include_pending:
        tx_qs = tx_qs.filter(state="posted")

    X_rows: List[Dict[str, Any]] = []
    y_labels: List[List[str]] = []
    for tx in tx_qs[:max_records]:
        entries = list(tx.journal_entries.all())
        if not entries or len(entries) > 4:
            # Skip transactions with no entries or too many entries (complex splits)
            continue
        labels = []
        for entry in entries:
            if entry.debit_amount:
                labels.append(f"debit:{entry.account_id}")
            elif entry.credit_amount:
                labels.append(f"credit:{entry.account_id}")
        if not labels:
            continue
        X_rows.append(
            {
                "description": tx.description or "",
                "amount": float(tx.amount),
            }
        )
        y_labels.append(labels)
    df = pd.DataFrame(X_rows)
    return df, y_labels


def train_journal_model(
    company_id: int,
    model_dir: str | None = None,
    max_records: int = 10000,
    include_pending: bool = False,
) -> str:
    """Train a multi‑label classifier for journal entry suggestion.

    The resulting model predicts sets of labels of the form
    ``"debit:<account_id>"`` and ``"credit:<account_id>"`` given the
    transaction description and amount. The model is saved to a pickle file
    ``journal_model_<company_id>.pkl`` in the specified directory.
    """
    X_df, y_labels = _assemble_journal_training_data(
        company_id=company_id,
        max_records=max_records,
        include_pending=include_pending,
    )
    if X_df.empty or not y_labels:
        raise RuntimeError("No journal training data available.")

    # Build a simple multi‑label classifier
    preprocessor = ColumnTransformer(
        transformers=[
            ("text", TfidfVectorizer(stop_words="english", max_features=5000), "description"),
            ("num", StandardScaler(), ["amount"]),
        ],
        remainder="drop",
    )
    classifier = OneVsRestClassifier(
        LogisticRegression(max_iter=1000, n_jobs=-1)
    )
    model = Pipeline([
        ("preprocessor", preprocessor),
        ("classifier", classifier),
    ])

    mlb = MultiLabelBinarizer()
    y_encoded = mlb.fit_transform(y_labels)

    model.fit(X_df, y_encoded)

    # Save the model and the label binarizer together as a tuple
    if model_dir is None:
        base_dir = getattr(settings, "BASE_DIR", os.getcwd())
        model_dir = os.path.join(base_dir, "models")
    os.makedirs(model_dir, exist_ok=True)
    model_path = os.path.join(model_dir, f"journal_model_{company_id}.pkl")
    joblib.dump((model, mlb), model_path)
    return model_path


def suggest_journal_entries(
    transaction: Any,
    model_path: str,
    top_k: int = 2,
) -> List[Dict[str, Any]]:
    """Suggest journal entry lines for a given transaction.

    Parameters
    ----------
    transaction : Any
        A transaction or dict with ``description`` and ``amount`` keys.
    model_path : str
        Path to the journal entry model pickle.
    top_k : int, optional
        Maximum number of journal entry labels to return. Defaults to 2.

    Returns
    -------
    list[dict[str, Any]]
        A list of suggestions where each suggestion contains keys
        ``type`` ("debit" or "credit"), ``account_id``, ``account_code``,
        ``account_name`` and ``probability``.
    """
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Journal model file not found: {model_path}")

    # Load the model and label binarizer
    model, mlb = joblib.load(model_path)
    # Prepare input row
    desc = transaction.get("description") if isinstance(transaction, dict) else getattr(transaction, "description", "")
    amount = transaction.get("amount") if isinstance(transaction, dict) else getattr(transaction, "amount", 0)
    X_df = pd.DataFrame([
        {
            "description": desc or "",
            "amount": float(amount),
        }
    ])
    # Predict probabilities for each label
    if hasattr(model, "predict_proba"):
        proba_matrix = model.predict_proba(X_df)
        proba = proba_matrix[0]
    else:
        # If the underlying estimator does not implement predict_proba,
        # fallback to binary predictions
        proba = model.predict(X_df)[0]
        proba = proba.astype(float)
    # Map probabilities to labels
    labels = mlb.classes_
    # Sort labels by probability descending
    sorted_indices = proba.argsort()[::-1][:top_k]
    suggestions: List[Dict[str, Any]] = []
    for idx in sorted_indices:
        label = labels[idx]
        prob = float(proba[idx])
        # Parse label into type and account_id
        if ":" in label:
            entry_type, account_id_str = label.split(":", 1)
            account_id = int(account_id_str)
        else:
            entry_type = "unknown"
            account_id = None
        account_code = None
        account_name = None
        if Account is not None and account_id is not None:
            try:
                account = Account.objects.get(id=account_id)
                account_code = account.account_code
                account_name = account.name
            except Account.DoesNotExist:
                pass
        suggestions.append(
            {
                "type": entry_type,
                "account_id": account_id,
                "account_code": account_code,
                "account_name": account_name,
                "probability": prob,
            }
        )
    return suggestions