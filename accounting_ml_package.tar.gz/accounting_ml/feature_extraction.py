"""
Feature extraction pipeline definitions for accounting transaction classification.

This module defines a scikit‑learn pipeline for converting raw transaction
objects into machine learning features. The pipeline currently uses a
combination of TF–IDF vectorisation on the transaction description and
standard scaling on numeric fields such as the transaction amount. If you
wish to incorporate additional metadata (e.g. dates, currencies, counterparty
names) you can extend the `build_preprocessor` function by adding
transformers to the `ColumnTransformer`.
"""

from __future__ import annotations

from typing import List

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

def build_preprocessor(text_column: str = "description", numeric_columns: List[str] | None = None) -> ColumnTransformer:
    """Constructs a ColumnTransformer that handles both text and numeric features.

    Parameters
    ----------
    text_column : str
        The name of the column containing free‑form transaction descriptions.
    numeric_columns : list[str] | None
        A list of column names containing numeric features (e.g. amount).

    Returns
    -------
    sklearn.compose.ColumnTransformer
        A transformer that converts raw columns into numeric arrays suitable for
        modelling.
    """
    # Default numeric columns if none provided
    if not numeric_columns:
        numeric_columns = ["amount"]

    # The TF–IDF vectoriser converts raw text into a sparse matrix of token weights.
    text_transformer = TfidfVectorizer(
        stop_words="english",
        max_features=10000,
        lowercase=True,
    )

    # StandardScaler scales numeric columns to zero mean and unit variance. We
    # wrap it in a FunctionTransformer so that it accepts a DataFrame and
    # returns a NumPy array. StandardScaler on its own expects a NumPy array
    # and would break if passed a DataFrame.
    numeric_transformer = Pipeline(steps=[
        (
            "scale",
            StandardScaler(),
        )
    ])

    # The ColumnTransformer directs columns to the appropriate transformer.
    preprocessor = ColumnTransformer(
        transformers=[
            ("text", text_transformer, text_column),
            ("num", numeric_transformer, numeric_columns),
        ],
        remainder="drop",
    )

    return preprocessor


def build_classification_model() -> Pipeline:
    """Creates a machine learning pipeline for account classification.

    The returned pipeline consists of the feature preprocessor followed by a
    `LogisticRegression` classifier. This classifier is well suited for
    multiclass problems and can output calibrated probabilities via
    `predict_proba`.

    Returns
    -------
    sklearn.pipeline.Pipeline
        A pipeline ready to be fitted on training data and used for
        predictions.
    """
    preprocessor = build_preprocessor()
    classifier = LogisticRegression(
        max_iter=1000,
        solver="lbfgs",
        n_jobs=-1,
        multi_class="auto",
    )
    model = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("classifier", classifier),
        ]
    )
    return model
