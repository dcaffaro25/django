"""
Training utilities for the accounting ML models.

This module provides functions to extract labelled training data from the
database and to train and persist classification models. The training data
uses verified journal entries (i.e. entries attached to posted transactions)
and assumes that human users have already reviewed and accepted the account
allocations. For each leaf account, the function collects the most recent
`records_per_account` entries and uses them as examples.

The primary entry point is :func:`train_categorization_model`, which
trains a model and saves it to the specified path. You can schedule this
function to run periodically (e.g. via a cron job or Celery beat) or
trigger it on demand via a management command.

Example:
    >>> from accounting_ml.train import train_categorization_model
    >>> model_path = train_categorization_model(company_id=1, records_per_account=500)
    >>> print(f"Model saved to {model_path}")
"""

from __future__ import annotations

import os
from collections import defaultdict
from datetime import datetime
from typing import Iterable, List, Dict, Any, Tuple

import pandas as pd
from django.conf import settings
from django.db.models import Prefetch, Q
from django.utils import timezone

from .feature_extraction import build_classification_model

# We import the accounting models lazily to avoid circular imports. When this
# module is used inside a Django context, these imports will resolve to the
# project's models. For static type checking, you can define TYPE_CHECKING
# imports.
try:
    from accounting.models import Account, JournalEntry, Transaction
except Exception:
    # When running outside of a full Django environment (e.g. in unit tests
    # without the app installed), these imports may fail. In that case we
    # simply set them to None. This allows static analysis but means that
    # training functions cannot execute.
    Account = None  # type: ignore
    JournalEntry = None  # type: ignore
    Transaction = None  # type: ignore

import joblib


def _collect_training_samples(
    company_id: int,
    records_per_account: int = 1000,
    include_pending: bool = False,
) -> pd.DataFrame:
    """Query the database for recent journal entries and build a training DataFrame.

    Parameters
    ----------
    company_id : int
        The ID of the company whose data should be used for training.
    records_per_account : int, optional
        The maximum number of entries per account to include. Older entries
        beyond this count are dropped. Defaults to 1000.
    include_pending : bool, optional
        Whether to include transactions with `state='pending'` in the
        training set. By default, only posted transactions (assumed to be
        verified) are used.

    Returns
    -------
    pandas.DataFrame
        A DataFrame with columns ``description``, ``amount`` and ``label``.

    Raises
    ------
    RuntimeError
        If the accounting models are unavailable (e.g. outside a Django context).
    """
    if Account is None or JournalEntry is None or Transaction is None:
        raise RuntimeError(
            "Accounting models are unavailable. Ensure this code runs inside a Django environment where the 'accounting' app is installed."
        )

    # Build a base queryset for journal entries. We restrict to the given
    # company and optionally exclude pending transactions.
    entry_qs = JournalEntry.objects.filter(
        account__company_id=company_id,
        account__is_active=True,
    ).select_related("transaction", "account")

    if include_pending:
        entry_qs = entry_qs.filter(
            Q(state="posted") | Q(state="pending"),
            Q(transaction__state="posted") | Q(transaction__state="pending"),
        )
    else:
        entry_qs = entry_qs.filter(state="posted", transaction__state="posted")

    # We only train on leaf accounts; internal accounts roll up children and
    # should not be predicted directly. We also ensure each account has a
    # non‑null ID and is not archived.
    leaf_accounts = (
        Account.objects.filter(company_id=company_id, is_active=True)
        .filter(children__isnull=True)
        .values_list("id", flat=True)
    )

    # Group entries by account and collect the most recent N entries for each.
    # We prefetch the related transaction to avoid repeated queries.
    account_samples: List[Dict[str, Any]] = []
    for account_id in leaf_accounts:
        qs = (
            entry_qs.filter(account_id=account_id)
            .order_by("-transaction__date")
            .select_related("transaction")[:records_per_account]
        )
        for entry in qs:
            tx = entry.transaction
            # Skip entries with missing transaction data
            if not tx:
                continue
            account_samples.append(
                {
                    "description": tx.description or "",
                    "amount": float(tx.amount),
                    "label": account_id,
                }
            )

    # Convert to DataFrame
    df = pd.DataFrame(account_samples)
    return df


def train_categorization_model(
    company_id: int,
    records_per_account: int = 1000,
    model_dir: str | None = None,
    include_pending: bool = False,
) -> str:
    """Train a transaction categorisation model and persist it to disk.

    Parameters
    ----------
    company_id : int
        The company whose transactions should be used for training.
    records_per_account : int, optional
        The maximum number of training examples to include per account. Older
        examples beyond this limit are ignored. Default is 1000.
    model_dir : str | None, optional
        The directory into which the trained model will be saved. If not
        provided, the path defaults to ``<project root>/models``. The file
        will be named ``categorization_model_{company_id}.pkl``.
    include_pending : bool, optional
        Whether to include pending transactions in the training data. By
        default only posted transactions are used.

    Returns
    -------
    str
        The absolute path of the saved model file.

    Raises
    ------
    RuntimeError
        If the training data is empty or the accounting models are unavailable.
    """
    if Account is None or JournalEntry is None or Transaction is None:
        raise RuntimeError(
            "Accounting models are unavailable. Ensure this code runs inside a Django environment where the 'accounting' app is installed."
        )

    # Assemble training data
    df = _collect_training_samples(
        company_id=company_id,
        records_per_account=records_per_account,
        include_pending=include_pending,
    )
    if df.empty:
        raise RuntimeError(
            f"No training data found for company {company_id}. Ensure there are posted journal entries and that the accounts have recent entries."
        )

    # Separate features and labels
    X = df[["description", "amount"]]
    y = df["label"]

    # Build and train the model
    model = build_classification_model()
    model.fit(X, y)

    # Determine output path
    if model_dir is None:
        # Default to a 'models' folder under the project base directory
        base_dir = getattr(settings, "BASE_DIR", os.getcwd())
        model_dir = os.path.join(base_dir, "models")
    os.makedirs(model_dir, exist_ok=True)
    model_path = os.path.join(model_dir, f"categorization_model_{company_id}.pkl")

    # Persist the model to disk
    joblib.dump(model, model_path)

    return model_path