"""
Django management command for training the categorisation model.

This command allows you to retrain the machine learning model on demand. It
accepts a company ID, optional number of examples per account and optional
output directory. By default, the model is saved under the project's
``models`` directory as ``categorization_model_<company_id>.pkl``. Use this
command in combination with a cron job or Celery beat to keep the model up to
date as new verified journal entries are created.
"""

from __future__ import annotations

from django.core.management.base import BaseCommand

from accounting_ml.train import train_categorization_model


class Command(BaseCommand):
    help = "Train the transaction categorisation model for a given company."

    def add_arguments(self, parser):
        parser.add_argument(
            "company_id", type=int, help="ID of the company whose transactions should be used for training."
        )
        parser.add_argument(
            "--n-per-account",
            type=int,
            default=1000,
            help="Maximum number of training samples to include per account (default: 1000)",
        )
        parser.add_argument(
            "--model-dir",
            type=str,
            default=None,
            help="Optional directory to save the trained model. Defaults to the project's 'models' directory.",
        )
        parser.add_argument(
            "--include-pending",
            action="store_true",
            help="Include pending transactions in the training data (in addition to posted ones).",
        )

    def handle(self, *args, **options):
        company_id = options["company_id"]
        n_per_account = options["n_per_account"]
        model_dir = options["model_dir"]
        include_pending = options["include_pending"]

        self.stdout.write(
            f"Training categorisation model for company {company_id} using up to {n_per_account} samples per account..."
        )
        try:
            model_path = train_categorization_model(
                company_id=company_id,
                records_per_account=n_per_account,
                model_dir=model_dir,
                include_pending=include_pending,
            )
        except Exception as exc:
            self.stderr.write(self.style.ERROR(f"Training failed: {exc}"))
            return

        self.stdout.write(self.style.SUCCESS(f"Model saved to {model_path}"))