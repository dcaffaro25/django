"""
Machine learning utilities for accounting transaction categorisation and journal entry suggestion.

This package is designed to plug into a Django project that uses the models
defined in the user's accounting application (see the provided `Account`,
`Transaction` and `JournalEntry` models). It exposes functions for
assembling training data from verified journal entries, training classification
models, persisting those models, and making predictions for new transactions.

You can integrate these functions into periodic tasks, management commands or
REST API endpoints to provide automatic categorisation and journal entry
suggestions in your backend. The models train on the most recent N
transactions per account to ensure they adapt to evolving business rules
without growing unbounded in size.

The core helper functions live in:

* `feature_extraction.py` – defines a feature extraction and modelling pipeline.
* `train.py` – assembles training data from the database and trains/saves the model.
* `predict.py` – loads the model and computes predictions for new transactions.

Additional modules can be added to extend functionality (e.g. for
multi‑output journal entry suggestion).
"""

__all__ = [
    "feature_extraction",
    "train",
    "predict",
]