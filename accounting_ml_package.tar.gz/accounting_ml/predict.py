"""
Prediction utilities for the accounting ML models.

This module exposes helper functions for loading a trained categorisation
model and using it to predict the most likely account for a new transaction.
It also includes a convenience wrapper to convert transactions (either
Django model instances or simple dict-like objects) into a format suitable
for the model.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Iterable, List, Optional, Tuple

import joblib
import pandas as pd
try:
    from django.conf import settings  # type: ignore
except Exception:
    # When Django is unavailable (e.g. during local testing outside the app),
    # provide a dummy settings object exposing a BASE_DIR attribute. This
    # allows functions that reference settings.BASE_DIR to work without
    # raising ImportError. You may override settings in your environment as
    # needed.
    import os
    import types

    settings = types.SimpleNamespace(BASE_DIR=os.getcwd())  # type: ignore

# Import the account model so that we can return human‑readable names
try:
    from accounting.models import Account
except Exception:
    Account = None  # type: ignore


def load_model(model_path: str) -> Any:
    """Load a trained model from disk.

    Parameters
    ----------
    model_path : str
        The file path to the pickle containing the trained model.

    Returns
    -------
    Any
        The deserialised scikit‑learn pipeline.

    Raises
    ------
    FileNotFoundError
        If the provided path does not exist.
    """
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")
    return joblib.load(model_path)


def _transaction_to_row(tx: Any) -> Dict[str, Any]:
    """Convert a transaction object into a dictionary for prediction.

    Accepts either a Django Transaction instance with ``description`` and
    ``amount`` attributes or any object/dict with those keys. Additional
    keys can be added here if the feature extractor is extended.

    Parameters
    ----------
    tx : Any
        A transaction or transaction‑like object.

    Returns
    -------
    dict
        A dictionary with keys matching the feature columns expected by the
        model (e.g. ``description``, ``amount``).
    """
    if isinstance(tx, dict):
        description = tx.get("description", "")
        amount = tx.get("amount", 0)
    else:
        description = getattr(tx, "description", "")
        amount = getattr(tx, "amount", 0)

    # Cast to appropriate types
    row = {
        "description": str(description) if description is not None else "",
        "amount": float(amount) if amount is not None else 0.0,
    }
    return row


def predict_top_accounts(
    transaction: Any,
    model_path: Optional[str] = None,
    top_n: int = 3,
) -> List[Tuple[int, float]]:
    """Predict the most likely accounts for a given transaction.

    Parameters
    ----------
    transaction : Any
        A transaction or transaction‑like object containing at least
        ``description`` and ``amount`` attributes.
    model_path : str | None, optional
        Path to the trained model. If omitted, defaults to a model in
        ``<BASE_DIR>/models/categorization_model_<company_id>.pkl``. In order
        to determine the correct file, this function attempts to resolve the
        company from the transaction's related account or entity. If that is
        unavailable, a value error is raised.
    top_n : int, optional
        The number of top predicted accounts to return. Defaults to 3.

    Returns
    -------
    list[tuple[int, float]]
        A list of tuples ``(account_id, probability)`` sorted by descending
        probability. The probability is between 0 and 1.

    Raises
    ------
    ValueError
        If the model path is not provided and the company cannot be
        determined.
    FileNotFoundError
        If the model file does not exist.
    """
    # Derive the company ID from the transaction if possible
    def _infer_company_id(obj: Any) -> Optional[int]:
        company_id = None
        if hasattr(obj, "company_id"):
            company_id = getattr(obj, "company_id")
        elif hasattr(obj, "entity") and hasattr(obj.entity, "company_id"):
            company_id = getattr(obj.entity, "company_id")
        return company_id

    # Resolve model path if not provided
    if model_path is None:
        company_id = _infer_company_id(transaction)
        if company_id is None:
            raise ValueError(
                "Model path must be supplied when the transaction does not carry a company_id attribute."
            )
        base_dir = getattr(settings, "BASE_DIR", os.getcwd())
        model_dir = os.path.join(base_dir, "models")
        model_path = os.path.join(model_dir, f"categorization_model_{company_id}.pkl")

    # Load the model
    model = load_model(model_path)

    # Prepare the row for prediction
    row = _transaction_to_row(transaction)
    df = pd.DataFrame([row])

    # If the model supports predict_proba, use it to get probabilities; otherwise
    # fall back to a binary decision (top N will be the predicted label with
    # probability 1.0)
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(df)[0]
        classes = model.classes_
        # Sort classes by probability descending
        sorted_indices = proba.argsort()[::-1][:top_n]
        results = [(int(classes[i]), float(proba[i])) for i in sorted_indices]
    else:
        # Use predict() and assign probability 1.0 to the predicted class
        label = int(model.predict(df)[0])
        results = [(label, 1.0)]
    return results


def predict_top_accounts_with_names(
    transaction: Any,
    model_path: Optional[str] = None,
    top_n: int = 3,
) -> List[Dict[str, Any]]:
    """Predict the top accounts and return human‑readable account names.

    In addition to the account IDs and probabilities, this function
    resolves the account objects to retrieve their names and codes. This is
    useful when returning predictions via an API or UI.

    Parameters
    ----------
    transaction : Any
        A transaction or transaction‑like object with at least description and
        amount attributes.
    model_path : str | None, optional
        Path to the model. See :func:`predict_top_accounts` for details.
    top_n : int, optional
        Number of top predictions to return.

    Returns
    -------
    list[dict[str, Any]]
        Each dictionary contains ``account_id``, ``account_code``,
        ``account_name`` and ``probability``.
    """
    results = predict_top_accounts(transaction, model_path, top_n)
    enriched: List[Dict[str, Any]] = []
    for account_id, prob in results:
        account_code = None
        account_name = None
        if Account is not None:
            try:
                account = Account.objects.get(id=account_id)
                account_code = account.account_code
                account_name = account.name
            except Account.DoesNotExist:
                pass
        enriched.append(
            {
                "account_id": account_id,
                "account_code": account_code,
                "account_name": account_name,
                "probability": prob,
            }
        )
    return enriched